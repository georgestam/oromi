This is the personal blog of @georgestam: [oromi.me](www.oromi.me).

The format and structure is a fork of the Jekyll template [so-simple](https://github.com/mmistakes/so-simple-theme).
